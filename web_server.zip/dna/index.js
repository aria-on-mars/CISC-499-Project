const express = require('express');
const axios = require('axios')
const fs = require('fs');
const path = require('path');
var child_process = require('child_process');
const { json } = require('express/lib/response');
const app = express();
const port = 9090;
const default_page = 'index.html';
const third_party_url = 'https://files.rcsb.org/download/';
const key_num = 'num_bpAA_contacts';
const key_contacts = 'bpAA_contacts';

// In case the pdb file is not found in cache,
// a get request will be sent to the third party.
const get_from_third_party = async (url) => {
    const response = await axios.get(url)
    return response.data;
}
  
app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
    res.status(200).sendFile(default_page, { 
        root: __dirname
    });
});

app.get('/index', function(req, res) {
    res.status(200).sendFile(default_page, { 
        root: __dirname
    });
});

app.get('/index.html', function(req, res) {
    res.status(200).sendFile(default_page, { 
        root: __dirname
    });
});

app.get('/download/*.pdb', function(req, res) {
    var filepath = path.join(__dirname, req.originalUrl);
    var filename = path.parse(filepath).base;
    fs.readFile(filepath, function(err, data) {
        if (err) {
            get_from_third_party(third_party_url + filename).then(
                data => {    
                    fs.writeFileSync(filepath, data.toString());
                    child_process.exec('./dnapro -i=' + filepath + ' --json --interface', function (err, stdout, stderr) {
                        if (err) {
                            console.log(">>> child processes failed with error code: " + err.code);
                            return;
                        }
                        fs.writeFileSync(filepath.replace(/\.[^/.]+$/, "") + ".tbl", stdout);
                        res.send(data.toString());
                    });
                }
            ).catch(err => {
                res.status(404).send(err);
            });
        } else {
            res.send(data.toString());
        }
    });
});

app.get('/download/*.tbl', function(req, res) {
    var filepath = path.join(__dirname, req.originalUrl);
    fs.readFile(filepath, function(err, data) {
        if (err) {
            res.status(404).send(err);
        } else {
            var d = JSON.parse(data.toString());
            var result = {};
            result[key_num] = 0;
            result[key_contacts] = 0;
            if (key_num in d && key_contacts in d) {
                result[key_num] = d[key_num];
                result[key_contacts] = d[key_contacts];
            }
            res.send(JSON.stringify(result));
        }
    });
})

app.listen(port, function() {
    console.log(`>>> server listen on port ${port}...`)
});