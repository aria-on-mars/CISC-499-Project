function append_extension(pdb) {
  if (pdb.split('.').pop() !== ".pdb") {
    pdb += ".pdb";
  }

  return pdb;
}

function add_table(num_bpAA_contacts, bpAA_contacts) {
  $("#table-01" ).remove();
  var content = "<table id='table-01' class='table table-dark table-hover'><thead class='thead-dark'><tr>";
  let keys = Object.keys(bpAA_contacts[0]);
  for (let i = 0; i < keys.length - 1; ++i) {
    content += "<th scope='col'>" + keys[i] + "</th>";
  }
  content += "</tr></thead><tbody>";
  for(let i = 0; i < num_bpAA_contacts; i++) {
    content += "<tr>";
    for (let j = 0; j < keys.length - 1; ++j) {
      content += "<td>" + bpAA_contacts[i][keys[j]] + "</td>";
    }
    content += "</tr>";
  }
  content += "</tbody></table>"
  $('#bpaa').append(content);
}

function downloadPDB(pdb) {
    pdb = append_extension(pdb);
    let tbl = pdb.replace(/\.[^/.]+$/, "") + ".tbl";
    let element = $('#container-01');
    let config = { backgroundColor: 'white' };
    let viewer = $3Dmol.createViewer( element, config );
    let pdbUri = "download/" + pdb;
    let tblUri = "download/" + tbl;
    jQuery.ajax( pdbUri, {
      beforeSend: function() {
        $('.ajax-loader').css("visibility", "visible");
        $("#table-01" ).remove();
      },
      success: function(pdbData) { 
        jQuery.ajax(tblUri, {
          success: function(jsonData) {
            $("#error").text("");   
            $('.ajax-loader').css("visibility", "hidden");    
            let v = viewer;
            v.addModel(pdbData, "pdb");                       /* load data */
            v.setStyle({}, {cartoon: {color: 'spectrum'}});   /* style all atoms */
            v.zoomTo();                                       /* set camera */
            let colorNames = ["red", "green", "blue", "yellow", "black", "purple", "cyan", "pink", "orange"];
            let d = JSON.parse(jsonData.toString());
            let num_bpAA_contacts = d["num_bpAA_contacts"];
            let bpAA_contacts = d["bpAA_contacts"];
            let chains = {};
            for (let i = 0; i < num_bpAA_contacts; ++i) {
              for (let col of ["nt1", "nt2", "aa"]) {
                let bpAA_contact = bpAA_contacts[i][col];
                let v = parseInt(bpAA_contact.match(/(\d+)/i)[0]);
                if (bpAA_contact[0] in chains) {
                  chains[bpAA_contact[0]].push(v);
                } else {
                  chains[bpAA_contact[0]] = [v];
                }
              }
            }

            for (const key in chains) {
              let color = 'gray';
              if (colorNames.length > 0) {
                color = colorNames.pop();
              }
              viewer.setStyle( {chain: key, resi: chains[key]}, {stick: { colorscheme: color + 'Carbon'}});  
            }
          
            v.render();                                      /* render scene */
            v.zoom(1.2, 1000);                               /* slight zoom */
            add_table(num_bpAA_contacts, bpAA_contacts);
          },
          error: function(hdr, status, err) {
            $("#error").text("Failed to load table " + tbl + ": " + err);
          },
        });
      },
      error: function(hdr, status, err) {
        $("#error").text("Failed to load PDB " + pdb + ": " + err);
      },
    });
  }